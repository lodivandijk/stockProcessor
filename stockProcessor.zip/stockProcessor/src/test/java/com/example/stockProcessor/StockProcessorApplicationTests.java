package com.example.stockProcessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
